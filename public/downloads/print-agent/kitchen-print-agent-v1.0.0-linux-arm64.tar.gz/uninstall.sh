#!/bin/bash
set -e

if [ "$EUID" -ne 0 ]; then
    echo "❌ Please run as root (use: sudo ./uninstall.sh)"
    exit 1
fi

SERVICE_NAME="kitchen-print-agent.service"

echo "Stopping and disabling service..."
systemctl stop "$SERVICE_NAME" 2>/dev/null || true
systemctl disable "$SERVICE_NAME" 2>/dev/null || true

rm -f "/etc/systemd/system/$SERVICE_NAME"
systemctl daemon-reload

rm -f "/usr/local/bin/kitchen-print-agent"

echo "✅ Kitchen Print Agent has been uninstalled."
