#!/bin/bash
set -e

if [ "$EUID" -ne 0 ]; then
    echo "❌ Please run as root (use: sudo ./install.sh)"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_NAME="kitchen-print-agent"
SERVICE_NAME="kitchen-print-agent.service"

echo "========================================================"
echo "    Kitchen Print Agent - Linux Installation"
echo "========================================================"

# Locate binary
SOURCE_BIN=""
if [ -f "$SCRIPT_DIR/$BIN_NAME" ]; then
    SOURCE_BIN="$SCRIPT_DIR/$BIN_NAME"
elif [ -f "$SCRIPT_DIR/../../dist/linux-amd64/$BIN_NAME" ]; then
    SOURCE_BIN="$SCRIPT_DIR/../../dist/linux-amd64/$BIN_NAME"
elif [ -f "$SCRIPT_DIR/../../$BIN_NAME" ]; then
    SOURCE_BIN="$SCRIPT_DIR/../../$BIN_NAME"
fi

if [ -z "$SOURCE_BIN" ] || [ ! -f "$SOURCE_BIN" ]; then
    echo "❌ Error: Could not find binary '$BIN_NAME'."
    exit 1
fi

echo "Copying binary to /usr/local/bin/$BIN_NAME..."
cp -f "$SOURCE_BIN" "/usr/local/bin/$BIN_NAME"
chmod 755 "/usr/local/bin/$BIN_NAME"

echo "Configuring systemd service..."
SERVICE_FILE="$SCRIPT_DIR/$SERVICE_NAME"
if [ ! -f "$SERVICE_FILE" ]; then
    SERVICE_FILE="$SCRIPT_DIR/scripts/linux/$SERVICE_NAME"
fi
cp -f "$SERVICE_FILE" "/etc/systemd/system/$SERVICE_NAME"

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

echo "========================================================"
echo "✅ SUCCESS! Kitchen Print Agent is installed and running."
echo "========================================================"
echo " - Service: systemctl status $SERVICE_NAME"
echo " - Health:  curl http://127.0.0.1:8088/health"
echo " - Logs:    journalctl -u $SERVICE_NAME -f"
echo "========================================================"
