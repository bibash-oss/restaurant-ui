#!/bin/bash
set -e

PLIST_NAME="com.kitchen.printagent.plist"
PLIST_DEST="$HOME/Library/LaunchAgents/$PLIST_NAME"
INSTALL_BIN="$HOME/.local/bin/kitchen-print-agent"

echo "========================================================"
echo "    Kitchen Print Agent - macOS Uninstallation"
echo "========================================================"

if [ -f "$PLIST_DEST" ]; then
    echo "Stopping and unloading LaunchAgent..."
    launchctl unload "$PLIST_DEST" 2>/dev/null || true
    rm -f "$PLIST_DEST"
fi

if [ -f "$INSTALL_BIN" ]; then
    echo "Removing binary $INSTALL_BIN..."
    rm -f "$INSTALL_BIN"
fi

echo "✅ Kitchen Print Agent has been uninstalled."
