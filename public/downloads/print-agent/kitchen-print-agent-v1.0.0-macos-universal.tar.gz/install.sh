#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_NAME="kitchen-print-agent"
INSTALL_DIR="$HOME/.local/bin"
LOG_DIR="$HOME/Library/Logs/KitchenPrintAgent"
LOG_FILE="$LOG_DIR/agent.log"
PLIST_NAME="com.kitchen.printagent.plist"
PLIST_DEST="$HOME/Library/LaunchAgents/$PLIST_NAME"

echo "========================================================"
echo "    Kitchen Print Agent - macOS Installation"
echo "========================================================"

# 1. Ensure directories exist
mkdir -p "$INSTALL_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$HOME/Library/LaunchAgents"

# 2. Locate binary
SOURCE_BIN=""
if [ -f "$SCRIPT_DIR/$BIN_NAME" ]; then
    SOURCE_BIN="$SCRIPT_DIR/$BIN_NAME"
elif [ -f "$SCRIPT_DIR/../../dist/macos/$BIN_NAME" ]; then
    SOURCE_BIN="$SCRIPT_DIR/../../dist/macos/$BIN_NAME"
elif [ -f "$SCRIPT_DIR/../../$BIN_NAME" ]; then
    SOURCE_BIN="$SCRIPT_DIR/../../$BIN_NAME"
fi

if [ -z "$SOURCE_BIN" ] || [ ! -f "$SOURCE_BIN" ]; then
    echo "❌ Error: Could not find binary '$BIN_NAME'."
    echo "Please build the project first using 'go build -o kitchen-print-agent main.go' or './build.sh'"
    exit 1
fi

# 3. Unload previous service if active
if launchctl list | grep -q "com.kitchen.printagent"; then
    echo "Stopping existing service..."
    launchctl unload "$PLIST_DEST" 2>/dev/null || true
fi

# 4. Copy binary
echo "Copying binary to $INSTALL_DIR/$BIN_NAME..."
cp -f "$SOURCE_BIN" "$INSTALL_DIR/$BIN_NAME"
chmod +x "$INSTALL_DIR/$BIN_NAME"

# 5. Generate and install launchd plist
echo "Configuring LaunchAgent service..."
PLIST_TEMPLATE="$SCRIPT_DIR/$PLIST_NAME"
if [ ! -f "$PLIST_TEMPLATE" ]; then
    PLIST_TEMPLATE="$SCRIPT_DIR/scripts/macos/$PLIST_NAME"
fi

sed -e "s|__AGENT_BIN_PATH__|$INSTALL_DIR/$BIN_NAME|g" \
    -e "s|__LOG_PATH__|$LOG_FILE|g" \
    "$PLIST_TEMPLATE" > "$PLIST_DEST"

# 6. Load service
echo "Starting Kitchen Print Agent service..."
launchctl load "$PLIST_DEST"

# 7. Verification
sleep 1
if launchctl list | grep -q "com.kitchen.printagent"; then
    echo "========================================================"
    echo "✅ SUCCESS! Kitchen Print Agent is installed and running."
    echo "========================================================"
    echo " - Status: Running in background (auto-starts on login)"
    echo " - URL: http://127.0.0.1:8088/health"
    echo " - Logs: $LOG_FILE"
    echo " - Uninstaller: ./uninstall.sh"
    echo "========================================================"
else
    echo "⚠️ Warning: Service loaded, but check status with: curl http://127.0.0.1:8088/health"
fi
