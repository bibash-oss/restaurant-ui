@echo off
setlocal
title Kitchen Print Agent - Installer

echo ========================================================
echo        Kitchen Print Agent - Windows Installation
echo ========================================================
echo.

set "TARGET_DIR=%LOCALAPPDATA%\KitchenPrintAgent"
set "EXE_NAME=kitchen-print-agent.exe"

echo [*] Target Directory: %TARGET_DIR%

:: 1. Create target directory
if not exist "%TARGET_DIR%" (
    mkdir "%TARGET_DIR%"
)

:: 2. Stop running instance if any
echo [*] Checking for running instances...
taskkill /f /im %EXE_NAME% >nul 2>&1
taskkill /f /im kitchen-print-agent-console.exe >nul 2>&1

:: 3. Copy executable
if exist "%~dp0%EXE_NAME%" (
    echo [*] Copying %EXE_NAME%...
    copy /y "%~dp0%EXE_NAME%" "%TARGET_DIR%\%EXE_NAME%" >nul
) else if exist "%~dp0kitchen-print-agent-console.exe" (
    echo [*] Copying console executable...
    copy /y "%~dp0kitchen-print-agent-console.exe" "%TARGET_DIR%\%EXE_NAME%" >nul
) else (
    echo [ERROR] %EXE_NAME% not found in the current folder!
    pause
    exit /b 1
)

:: 4. Add to Windows Startup Registry (runs automatically on login)
echo [*] Configuring automatic startup on Windows boot...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "KitchenPrintAgent" /t REG_SZ /d "\"%TARGET_DIR%\%EXE_NAME%\"" /f >nul
if %errorlevel% neq 0 (
    echo [WARNING] Failed to add startup registry entry.
) else (
    echo [*] Auto-start on boot configured successfully.
)

:: 5. Launch agent now
echo [*] Starting Kitchen Print Agent in the background...
start "" "%TARGET_DIR%\%EXE_NAME%"

echo.
echo ========================================================
echo  SUCCESS! Kitchen Print Agent is installed and running!
echo ========================================================
echo  - Port: http://127.0.0.1:8088
echo  - Auto-start: Enabled on Windows logon
echo  - To uninstall: Run uninstall.bat
echo ========================================================
echo.
pause
