@echo off
setlocal
title Kitchen Print Agent - Uninstaller

echo ========================================================
echo        Kitchen Print Agent - Windows Uninstallation
echo ========================================================
echo.

set "TARGET_DIR=%LOCALAPPDATA%\KitchenPrintAgent"
set "EXE_NAME=kitchen-print-agent.exe"

:: 1. Terminate running process
echo [*] Stopping Kitchen Print Agent...
taskkill /f /im %EXE_NAME% >nul 2>&1
taskkill /f /im kitchen-print-agent-console.exe >nul 2>&1

:: 2. Remove registry startup entry
echo [*] Removing startup registry entry...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "KitchenPrintAgent" /f >nul 2>&1

:: 3. Remove installed files
if exist "%TARGET_DIR%" (
    echo [*] Removing files from %TARGET_DIR%...
    rmdir /s /q "%TARGET_DIR%" >nul 2>&1
)

echo.
echo ========================================================
echo  Kitchen Print Agent has been completely removed.
echo ========================================================
echo.
pause
