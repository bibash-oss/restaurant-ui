Kitchen Print Agent - Windows Installation Guide
==================================================

QUICK START:
1. Double-click "install.bat"
2. That's it! The agent will start automatically now and every time Windows boots.

VERIFY:
Open your web browser and visit:
http://127.0.0.1:8088/health

UNINSTALL:
Double-click "uninstall.bat" to stop and remove the agent completely.

DEBUGGING:
If you want to run the agent in an open console window to view real-time logs,
double-click "kitchen-print-agent-console.exe".
